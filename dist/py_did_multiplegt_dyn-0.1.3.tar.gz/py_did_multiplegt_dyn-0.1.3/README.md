# py_did_multiplegt_dyn
This is the python version of the main Stata package did_multiplegt_dyn.
